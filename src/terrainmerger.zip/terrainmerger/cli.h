#ifndef CLI_H
#define CLI_H

#include <filesystem>
#include <vector>
#include <optional>

#include <tl/expected.hpp>
#include <CLI/CLI.hpp>

namespace cli {
    struct SimplificationArgs {
        double simplification_factor;
        // double simplification_target_error;
    };

    struct Args {
        std::filesystem::path output_path;
        std::vector<std::filesystem::path> input_paths;
        std::optional<SimplificationArgs> simplification;
    };

    Args parse(int argc, char **argv) {
        CLI::App app{"Terrain Merger"};
        // app.allow_windows_style_options();
        argv = app.ensure_utf8(argv);
        
        std::vector<std::filesystem::path> input_paths;
        app.add_option("--input", input_paths, "Paths to tiles that should be merged")
            ->required()
            ->expected(-1)
            ->check(CLI::ExistingFile);

        std::filesystem::path output_path;
        app.add_option("--output", output_path, "Path to output the merged tile to")
            ->required();

        bool no_mesh_simplification = false;
        app.add_flag("--no-simplify", no_mesh_simplification, "Disable mesh simplification");

        float simplification_factor = 0.25f;
        app.add_option("--simplify-factor", simplification_factor, "Mesh index simplification factor")
            ->check(CLI::Range(0.0f, 1.0f))
            ->excludes("--no-simplify");

        float simplification_target_error = 0.01f;
        app.add_option("--simplify-error", simplification_target_error, "Mesh simplification target error")
            ->check(CLI::Range(0.0f, 1.0f))
            ->excludes("--no-simplify");

        // TODO: Add option to specify the verbosity level

        try {
            app.parse(argc, argv);
        } catch (const CLI::ParseError &e) {
            exit(app.exit(e));
        }

        Args args;
        args.input_paths = input_paths;
        args.output_path = output_path;
        if (!no_mesh_simplification) {
            SimplificationArgs simplification_args;
            simplification_args.simplification_factor = simplification_factor;
            args.simplification = simplification_args;
        }

        return args;
    }
}; // namespace cli

#endif
