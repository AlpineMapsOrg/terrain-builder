#ifndef CONVERT_H
#define CONVERT_H

#include <vector>

#include <opencv2/opencv.hpp>
#include <glm/glm.hpp>
#include <fmt/core.h>

#include "terrain_mesh.h"
#include "fi_image.h"
#include "cgal.h"

namespace convert {
    
glm::dvec3 cgal2glm(Point3 point) {
    return glm::dvec3(point[0], point[1], point[2]);
}
glm::dvec2 cgal2glm(Point2 point) {
    return glm::dvec2(point[0], point[1]);
}
Point3 glm2cgal(glm::dvec3 point) {
    return Point3(point[0], point[1], point[2]);
}
Point2 glm2cgal(glm::dvec2 point) {
    return Point2(point[0], point[1]);
}

SurfaceMesh mesh2cgal(const TerrainMesh& mesh) {
    SurfaceMesh cgal_mesh;

    for (const glm::dvec3 &position : mesh.positions) {
        const CGAL::SM_Vertex_index vertex = cgal_mesh.add_vertex(glm2cgal(position));
        assert(vertex != SurfaceMesh::null_vertex());
    }

    for (const glm::uvec3 &triangle : mesh.triangles) {
        if (triangle[0] > 10000 && triangle[1] < 10000) {
            int a = 1;
        }
        CGAL::SM_Face_index face = cgal_mesh.add_face(
            CGAL::SM_Vertex_index(triangle.x),
            CGAL::SM_Vertex_index(triangle.y),
            CGAL::SM_Vertex_index(triangle.z));

        if (face == SurfaceMesh::null_face()) {
            fmt::println("Adding face failed, trying again with different order");
            face = cgal_mesh.add_face(
                CGAL::SM_Vertex_index(triangle.x),
                CGAL::SM_Vertex_index(triangle.z),
                CGAL::SM_Vertex_index(triangle.y));
        }
        assert(face != SurfaceMesh::null_face());
    }

#if DEBUG
    assert(cgal_mesh.is_valid(true));
    assert(CGAL::is_triangle_mesh(cgal_mesh));
#endif

    return cgal_mesh;
}
TerrainMesh cgal2mesh(const SurfaceMesh& cgal_mesh) {
    TerrainMesh mesh;

    const size_t vertex_count = CGAL::num_vertices(cgal_mesh);
    const size_t face_count = CGAL::num_faces(cgal_mesh);
    mesh.positions.reserve(vertex_count);
    mesh.uvs.reserve(vertex_count);
    mesh.triangles.reserve(face_count);

    // TODO
    std::vector<unsigned int> mapmapmap;
    mapmapmap.resize(vertex_count);

    for (const CGAL::SM_Vertex_index vertex_index : cgal_mesh.vertices()) {
        const Point3 &position = cgal_mesh.point(vertex_index);
        mapmapmap[vertex_index] = mesh.positions.size();
        mesh.positions.push_back(cgal2glm(position));
    }
    
    for (const CGAL::SM_Face_index face_index : cgal_mesh.faces()) {
        std::array<unsigned int, 3> triangle;
        unsigned int i = 0;
        for (const CGAL::SM_Vertex_index vertex_index : CGAL::vertices_around_face(cgal_mesh.halfedge(face_index), cgal_mesh)) {
            triangle[i] = mapmapmap[vertex_index];
            i++;
        }
        mesh.triangles.emplace_back(triangle[0], triangle[1], triangle[2]);
    }

    return mesh;
}

cv::Mat fi2cv(const FiImage& image) {
    std::vector<uint8_t> buffer = image.save_to_vector(FIF_PNG);
    cv::Mat mat = cv::imdecode(cv::Mat(1, buffer.size(), CV_8UC1, buffer.data()), cv::IMREAD_UNCHANGED);
    mat.convertTo(mat, CV_32FC3);
    return mat;
}

FiImage cv2fi(const cv::Mat& image) {
    assert(!image.empty());

    cv::Mat converted;
    std::vector<uint8_t> buffer;
    image.convertTo(converted, CV_8UC3);
    cv::imshow("dwada", converted);
    cv::imencode(".png", image, buffer);
    return FiImage::load_from_buffer(buffer);
}

}

#endif
